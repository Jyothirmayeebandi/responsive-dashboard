// src/components/UserCard.js
import React from 'react';

const UserCard = ({ user, onViewDetails }) => (
  <div className="user-card">
    <h3>{user.name}</h3>
    <p>@{user.username}</p>
    <button onClick={() => onViewDetails(user)}>View Details</button>
  </div>
);

export default UserCard;
