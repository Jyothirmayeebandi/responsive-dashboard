// src/components/Dashboard.js
import React, { useState, useEffect } from 'react';
import { fetchUsers } from '../services/api';
import UserCard from './UserCard';
import Modal from 'react-modal';
import './Dashboard.css'; // Import a separate CSS file for the component

const Dashboard = () => {
  const [users, setUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortOption, setSortOption] = useState('');
  const [selectedUser, setSelectedUser] = useState(null);

  useEffect(() => {
    const getUsers = async () => {
      const usersData = await fetchUsers();
      setUsers(usersData);
    };
    getUsers();
  }, []);

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleSort = (event) => {
    setSortOption(event.target.value);
  };

  const handleViewDetails = (user) => {
    setSelectedUser(user);
  };

  const closeModal = () => {
    setSelectedUser(null);
  };

  const filteredUsers = users
    .filter((user) =>
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.username.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      if (sortOption === 'name') {
        return a.name.localeCompare(b.name);
      } else if (sortOption === 'username') {
        return a.username.localeCompare(b.username);
      }
      return 0;
    });

  return (
    <div className="dashboard">
      <div className="controls">
        <input
          type="text"
          placeholder="Search by name or username"
          value={searchTerm}
          onChange={handleSearch}
        />
        <select value={sortOption} onChange={handleSort}>
          <option value="">Sort by</option>
          <option value="name">Name</option>
          <option value="username">Username</option>
        </select>
      </div>
      <div className="user-list">
        {filteredUsers.map((user) => (
          <UserCard key={user.id} user={user} onViewDetails={handleViewDetails} />
        ))}
      </div>
      {selectedUser && (
        <Modal
          isOpen={!!selectedUser}
          onRequestClose={closeModal}
          className="modal"
          overlayClassName="modal-overlay"
        >
          <h2>{selectedUser.name}</h2>
          <p>Username: {selectedUser.username}</p>
          <p>Email: {selectedUser.email}</p>
          <p>Phone: {selectedUser.phone}</p>
          <p>Website: {selectedUser.website}</p>
          <p>Address: {`${selectedUser.address.suite}, ${selectedUser.address.street}, ${selectedUser.address.city}`}</p>
          <button className= "close-btn" onClick={closeModal}>Close</button>
        </Modal>
      )}
    </div>
  );
};

export default Dashboard;
